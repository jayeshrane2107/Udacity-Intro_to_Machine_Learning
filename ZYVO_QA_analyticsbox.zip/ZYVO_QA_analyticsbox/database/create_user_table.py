import sqlite3
conn = sqlite3.connect('analytical_box.db')
c = conn.cursor()

c.execute("delete from user")
c.execute("drop table user")
c.execute('create table if not exists user(user_id integer primary key autoincrement,\
                                           username string(100) not null,\
                                           password string(500) not null,\
                                           admin boolean not null,\
                                           access boolean not null)')


c.execute("delete from output")
c.execute("drop table output")
c.execute('create table if not exists output(candidate_id integer(10) not null,\
                                           organization_name string(100) not null,\
                                           model_name string(100) not null,\
                                           prediction_0 real(50) not null,\
                                           prediction_1 real(50) not null,\
                                           precision real(50) not null,\
                                           date string(25) not null,\
                                           value, primary key (candidate_id, organization_name, model_name))')

c.execute("delete from model")
c.execute("drop table model")
c.execute('create table if not exists model(model_id integer primary key,\
                                           model_name string(100) not null,\
                                           hashed_model_name string(100) not null,\
                                           model_path string(500) not null)')

c.execute("delete from organization")
c.execute("drop table organization")
c.execute('create table if not exists organization(organization_id integer primary key,\
                                           organization_name string(50) not null unique,\
                                           hashed_org_name string(100) not null,\
                                           model_access string(100) not null,\
                                           generalised_model string(50))')

c.execute("insert into user values(1,'zyvo_admin','sha256$LU4uLf0D$5212c68d9a9f7bbf209343bed6df95c07a670dc9ef924a4e791982e2f02db140',1,1)")
#c.execute("insert into output values(1,16,1,1,'[0.337890625,0.6621093749999999]',0.5747663551401869)")

conn.commit()
c.close()
conn.close()


