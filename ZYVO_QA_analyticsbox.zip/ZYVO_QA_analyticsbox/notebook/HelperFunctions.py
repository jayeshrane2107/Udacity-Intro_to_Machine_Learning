﻿#
#Class containing helper functions to aid classification model creation
#
import math
from operator import itemgetter
import numpy as np
from random import randrange, choice, sample
from sklearn.neighbors import NearestNeighbors
from sklearn import naive_bayes, ensemble, cross_validation, metrics, linear_model, feature_selection, grid_search, neural_network, svm, pipeline, linear_model, tree, preprocessing, decomposition
import sklearn.datasets as ds
import array
import random
import numpy
import copy
import pickle
import collections
from sklearn.base import TransformerMixin

import warnings
warnings.filterwarnings("ignore")

class Classifier:

    #normalize either rank or competency score depending on whether 'ranking' is true
    def NormalizeRanking(self, totalRankAmounts, source, ranking):
        first = True
        n=-1
        allReviews = []
        currentReviewer = ""
        #read file with trainingset
        for subject in source:                                      
            #group reviews by reviewer
            if subject[7] != currentReviewer:                     
                n = n+1
            #if ranking is true = use ranking, otherwise use competency score
            if ranking:
                try:
                    subject[49] = int(subject[49]) / totalRankAmounts[n]
                except:
                    subject[49] = (1 - int(subject[37]) / 5)
            else:
                if len(subject) <50 :
                    subject.append(0)

                subject[49] = int(subject[37]) / 5
            allReviews.append(subject)
            currentReviewer = subject[7]
        return allReviews

    #normalize either rank or competency score depending on whether 'ranking' is true
    def NormalizeRankingDict(self, totalRankAmounts, source, ranking):
        first = True
        n=-1
        currentReviewer = ""
        #read file with trainingset
        for subject in sorted(source.values()):                                      
            #group reviews by reviewer
            if subject['supervisor'] != currentReviewer:                     
                n = n+1
            #if ranking is true = use ranking, otherwise use competency score
            if ranking:
                try:
                    subject['question 6'] = int(subject['question 6']) / totalRankAmounts[n]
                except:
                    subject['question 6'] = int(subject['question 0']) / 5
            else:
                subject['question 6'] = int(subject['question 0']) / 5
            currentReviewer = subject['supervisor']
        return source

    #returns lowest % reviews per reviewer
    #Not taking into account the subjects that did not participate in our survey
    def LowestReviews(self, percentage, allSubjects):          
        lowestReviews = []
        OverallLowestReviews = []
        currentReviewer = ""

        #read file with trainingset
        for subject in allSubjects:
            #group reviews by reviewer
            if subject[7] != currentReviewer:                     
                lowestReviews.append([])
                lowestReviews[len(lowestReviews)-1].append(subject)
            else :
                lowestReviews[len(lowestReviews)-1].append(subject)
            currentReviewer = subject[7]

        #put lowest % reviews for each reviewer in OverallLowestReviews
        for i in range(len(lowestReviews)):                         
            lw = sorted(lowestReviews[i], key = itemgetter(49))
            amountReviews = math.ceil(len(lw) * (percentage/100))

            for j in range(amountReviews):
                if len(lw) >= j:
                    OverallLowestReviews.append(lw[j])
    
        return OverallLowestReviews

    #returns lowest % reviews per reviewer
    #Not taking into account the subjects that did not participate in our survey
    def LowestReviewsDict(self, percentage, allSubjects):          
        lowestReviews = {}
        OverallLowestReviews = {}
        currentReviewer = ""

        #read file with trainingset
        for subject in sorted(allSubjects.values()):
            #group reviews by reviewer
            if subject['supervisor'] != currentReviewer:                     
                lowestReviews[subject['supervisor']] = 1
            else :
                lowestReviews[subject['supervisor']] += 1
            currentReviewer = subject['supervisor']

        #put lowest % reviews for each reviewer in OverallLowestReviews
        for subject in allSubjects:
            if subject['question 6'] > math.ceil(lowestReviews[subject['supervisor']] * (percentage/100)):
                subject['bottomClass'] = False
            else:
                subject['bottomClass'] = True
    
        return allSubjects

    #Read entire file and return input as list
    def ReadAll (self, file):               
        out = []
        dictionary = {}
        first = True
        for line in file:
            if first:
                first = not first
            else:
                line = line.split(";")
                out.append(line)
                
        return out

    #Read entire file and return input as list
    def ReadAllDict (self, file):               
        dictionary = {}
        first = True
        for line in file:
            if first:
                first = not first
            else:
                line = line.split(";")
                dictionary[line[0]] = {'employeeID':line[1],'department':line[2],'wtf':line[3],'dateOfBirth':line[4],'employedSince':line[5],'educationType':line[6],
                                       'supervisor':line[7],'team':line[8],'gender':line[9],'qualified':line[10],'teacherScale':line[11],
                                       'actiegerichtheid':line[12],'behoefte aan regels':line[13],'behoefte aan spanning':line[14],'beinvloedingsvermogen':line[15],'detailgerichtheid':line[16],
                                       'doorzettingsvermogen':line[17],'eigen verantwoordelijkheid':line[18],'eigenbelang':line[19],'focus':line[20],'impulsbeheersing':line[21],
                                       'meevoelendheid':line[22],'oorzaak-analyze':line[23],'optimisme':line[24],'profileringsdrang':line[25],'rationaliteit':line[26],
                                       'sociabliteit':line[27],'stressgevoeligheid':line[28],'verbeeldingskracht':line[29],'vertrouwen in anderen':line[30],'werkorganisatie':line[31],
                                       'werktempo':line[32],'zelfbeheersing':line[33],'zelfwaardering':line[34],'zelfwerkzaamheid':line[35],'question 0':line[37],
                                       'question 1':line[39],'question 2':line[41],'question 3':line[43],'question 4':line[45],'question 5':line[47],'question 6':line[49]}
                
        return dictionary

    #Remove columns with information we don't need. Like name, employee number, etc.
    def RemoveIrrelevantColumns(self, subjects, personalFeaturesOnly):    
        for i in range(len(subjects)):
            subjects[i] = subjects[i][3:36]
            subjects[i] = subjects[i][:4] + subjects[i][6:]

            for j in range(len(subjects[i])):
                if subjects[i][j] != '':
                    if j != 49:
                        subjects[i][j] = float(subjects[i][j].replace(",", "."))
                else:
                    subjects[i][j] = 0

        if personalFeaturesOnly:
            subjects = [row[7:] for row in subjects]

        return subjects

    #assign binary class to all rows, based on predefined list of rows with class 0
    def AssignClasses(self, subjects, bottomClass):    
        classArray = []
        for i in range(len(subjects)):
            found = False

            for j in range(len(bottomClass)):
                if subjects[i] == bottomClass[j] :
                   found = True
                   break

            if found:
                classArray.append(0)
            else:
                classArray.append(1)

        return classArray

    #Synthetic sample generation, taken from http://comments.gmane.org/gmane.comp.python.scikit-learn/5278!!!!!!!!!!!!!!!
    def SMOTE(self, T, N, k): 
        """
        Returns (N/100) * n_minority_samples synthetic minority samples.
        
        Parameters
        ----------
        T : array-like, shape = [n_minority_samples, n_features]
            Holds the minority samples
        N : percetange of new synthetic samples: 
            n_synthetic_samples = N/100 * n_minority_samples. Can be < 100.
        k : int. Number of nearest neighbours. 
        
        Returns
        -------
        S : array, shape = [(N/100) * n_minority_samples, n_features]
        """    
        n_minority_samples, n_features = T.shape
    
        if N < 100:
            #create synthetic samples only for a subset of T.
            #TODO: select random minortiy samples
            N = 100
            pass

        if (N % 100) != 0:
            raise ValueError("N must be < 100 or multiple of 100")
    
        N = N/100
        n_synthetic_samples = N * n_minority_samples
        S = np.zeros(shape=(n_synthetic_samples, n_features))
    
        #Learn nearest neighbours
        neigh = NearestNeighbors(n_neighbors = k)
        neigh.fit(T)
    
        #Calculate synthetic samples
        for i in range(n_minority_samples):
            nn = neigh.kneighbors(T[i], return_distance=False)
            for n in range(int(N)):
                nn_index = choice(nn[0])
                #NOTE: nn includes T[i], we don't want to select it 
                while nn_index == i:
                    nn_index = choice(nn[0])
                
                dif = T[nn_index] - T[i]
                gap = 0.4#np.random.random()
                S[n + i * N, :] = T[i,:] + gap * dif[:]
    
        return S
    
    #feature selection by sci kit, mode=1 is anova K best, mode=2 is false positive rate test
    def FeatureSelection(self, trainSet, trainTarget, testSet, mode, kVal):
        
        #kVal best features returned
        if(mode == 1):
            featureSel = feature_selection.SelectKBest(feature_selection.f_classif, k = kVal).fit(trainSet, trainTarget)

        #false positive rate below 0.05 are accepted
        if(mode == 2):
            featureSel = feature_selection.SelectFpr(feature_selection.f_classif, 0.05).fit(trainSet, trainTarget)
        
        trainSet1 = featureSel.transform(trainSet).tolist()
        testSet1 = featureSel.transform(testSet).tolist()

        return [trainSet1, testSet1, featureSel]

    #shuffle 2 lists in the same order
    def shuffle(self, list1, list2):
        combo = list(zip(list1, list2))
        random.shuffle(combo)
        list1, list2 = zip(*combo)
        list1 = list(list1)
        list2 = list(list2)

        return [list1, list2]

    #generate 10 classifiers and return mean of metrics
    def single10FoldForest(self, allSubjects, bottomClass, kVal, folds, pcaVal):

        c = Classifier()

        #preprocessing
        classArray = c.AssignClasses(allSubjects, bottomClass)
        classArray, allSubjects = c.shuffle(classArray, allSubjects)
        allSubjectsOriginal = copy.copy(allSubjects)
        allSubjects = c.RemoveIrrelevantColumns(allSubjects, False)
        bottomClass = c.RemoveIrrelevantColumns(bottomClass, False)

        #initialisation
        allSubjects = np.array(allSubjects)
        classArray = np.array(classArray)
        precisiontop5 = []
        precision1 = []
        precision0 = []
        auc = []
        recall1 = []
        recall0 = []
        acc = []
        outputClasses = []
        testClasses = []
        unsortedOutputProba = []
        outputProbaManualClass = [[],[],[]]
        ManualMetrics = [[[],[],[],[],[]],[[],[],[],[],[]],[[],[],[],[],[]]]
        Metrics = {'precision0':[], 'precision1':[], 'auc':[], 'recall0':[], 'recall1':[]}
        ManualMetricsDict = collections.OrderedDict()
        ManualMetricsDict['60-40']=copy.deepcopy(Metrics)
        ManualMetricsDict['80-20']=copy.deepcopy(Metrics)
        ManualMetricsDict['100-0']=copy.deepcopy(Metrics)
        targetManualClass = [[],[],[]]
        outcome = {'target':[], 'prediction':[]}
        ManualClassDict = {'60-40':copy.deepcopy(outcome), '80-20':copy.deepcopy(outcome), '100-0':copy.deepcopy(outcome)}

        midClass = []
        topClassCorrect = []
        bottomClassCorrect = []
        currAUC = 0

        #go through all folds
        for trainI, testI in folds:
            testSet = [item.tolist() for item in allSubjects[testI]]
            testSetOriginal = [item for item in np.array(allSubjectsOriginal)[testI]]
            testTarget = [item.tolist() for item in classArray[testI]]

            trainAll = allSubjects[trainI].tolist()

            #synthetic sample generation for trainset
            trainTopClass = [item for item in trainAll if item not in bottomClass]
            trainBottomClass = [item for item in trainAll if item in bottomClass]
            trainTarget = [item.tolist() for item in classArray[trainI]]

            #if topClass is bigger than bottomClass create synthetic bottom samples
            if (len(trainTopClass) > len(trainBottomClass)):
                size = (round(float((len(trainTopClass)) / (len(trainBottomClass)) - 1), 0)) * 100
                if size > 0:
                    syntheticClass = c.SMOTE(np.array(trainBottomClass), size, 3).tolist()
                    for i in range(len(syntheticClass)):
                        trainTarget.append(0)
                else:
                    syntheticClass = []
            #if bottomClass > topClass create synthetic top samples
            else:
                size = (round(float((len(trainBottomClass)) / (len(trainTopClass)) - 1), 0)) * 100
                if size > 0:
                    syntheticClass = c.SMOTE(np.array(trainTopClass), size, 3).tolist()
                    for i in range(len(syntheticClass)):
                        trainTarget.append(1)
                else:
                    syntheticClass = []

            #add synthetic samples to trainset
            trainSet = [item.tolist() for item in allSubjects[trainI]] + syntheticClass

            #shuffle samples
            trainTarget, trainSet = c.shuffle(trainTarget, trainSet)

            #PCA
            pca = decomposition.PCA(pcaVal)
            pca.fit(trainSet)
            testSet = pca.transform(testSet)
            trainSet = pca.transform(trainSet)

            #select kVal features
            [trainSet, testSet, featureSel] = c.FeatureSelection(trainSet, trainTarget, testSet, 1, kVal)

            #classifier training
            forest = ensemble.ExtraTreesClassifier(n_estimators=128,    criterion="gini",           max_depth=None,    min_samples_split=2, 
                                                    min_samples_leaf=1, min_weight_fraction_leaf=0, max_features="sqrt", max_leaf_nodes=None, 
                                                    bootstrap=True,     oob_score=True,             n_jobs=-1,          random_state=None,
                                                    verbose=0,          warm_start=False,           class_weight="auto")
            classifier = ensemble.AdaBoostClassifier(base_estimator = forest, n_estimators=300, learning_rate=0.2)
            classifier.fit(trainSet, trainTarget)
            
            #Predict output for test set
            output = classifier.predict(testSet).tolist()
            outputProba = classifier.predict_proba(testSet).tolist()
            
            #separate mid, top and bottom class (where *ClassCorrect = true positives, and probaManualCLass = all predictions with a probability > 0.6
            tempoutputProba = copy.copy(outputProba)
            tempoutputProba = [row[1] for row in tempoutputProba]
            tempProbaManualClass = [[],[],[]]
            temptargetManualClass = [[],[],[]]

            for i in range(len(tempoutputProba)):
                if tempoutputProba[i] >= 0.5:

                    if tempoutputProba[i] <= 0.6:
                        tempProbaManualClass[0].append(1)
                        temptargetManualClass[0].append(testTarget[i])

                        ManualClassDict['60-40']['prediction'].append(1)
                        ManualClassDict['60-40']['target'].append(testTarget[i])
                    elif tempoutputProba[i] <= 0.8:
                        tempProbaManualClass[1].append(1)
                        temptargetManualClass[1].append(testTarget[i])

                        ManualClassDict['80-20']['prediction'].append(1)
                        ManualClassDict['80-20']['target'].append(testTarget[i])
                    else:
                        tempProbaManualClass[2].append(1)
                        temptargetManualClass[2].append(testTarget[i])

                        ManualClassDict['100-0']['prediction'].append(1)
                        ManualClassDict['100-0']['target'].append(testTarget[i])

                    if testTarget[i] == 1:
                        topClassCorrect.append(testSetOriginal[i])
                
                elif tempoutputProba[i] < 0.5:

                    if tempoutputProba[i] >= 0.4:
                        tempProbaManualClass[0].append(0)
                        temptargetManualClass[0].append(testTarget[i])

                        ManualClassDict['60-40']['prediction'].append(0)
                        ManualClassDict['60-40']['target'].append(testTarget[i])
                    elif tempoutputProba[i] >= 0.2:
                        tempProbaManualClass[1].append(0)
                        temptargetManualClass[1].append(testTarget[i])

                        ManualClassDict['80-20']['prediction'].append(0)
                        ManualClassDict['80-20']['target'].append(testTarget[i])
                    else:
                        tempProbaManualClass[2].append(0)
                        temptargetManualClass[2].append(testTarget[i])

                        ManualClassDict['100-0']['prediction'].append(0)
                        ManualClassDict['100-0']['target'].append(testTarget[i])

                    if testTarget[i] == 0:
                        bottomClassCorrect.append(testSetOriginal[i])
                else:
                    midClass.append(testSetOriginal[i])

            for i in range(3):
                outputProbaManualClass[i].append(tempProbaManualClass[i])
                targetManualClass[i].append(temptargetManualClass[i])

            unsortedOutputProba.append(tempoutputProba)
            
            #create sorted output to calculate precision at 5 (per fold)
            copytestTarget = copy.copy(testTarget)
            outputsorted = copy.copy(output)
            outputProba, copytestTarget, outputsorted = zip(*sorted(zip(outputProba, copytestTarget, outputsorted)))

            #metrics
            precisiontop5.append(metrics.precision_score(copytestTarget[:5], outputsorted[:5]))
            precision1.append(metrics.precision_score(testTarget, output, pos_label = 1, average = 'binary'))
            precision0.append(metrics.precision_score(testTarget, output, pos_label = 0, average = 'binary'))
            try:
                auc.append(metrics.roc_auc_score(testTarget, output))
            except:
                auc.append(0.5)

            recall1.append(metrics.recall_score(testTarget, output))

            testTarget0 = [1 if x==0 else 0 for x in testTarget]
            output0 = [1 if x==0 else 0 for x in output]

            recall0.append(metrics.recall_score(testTarget0, output0))
            acc.append(metrics.accuracy_score(testTarget, output))
            
            outputClasses.append(output)
            testClasses.append(testTarget)

            #ManualClass = predictions based on probability > 0.6, >0.8, >0.8<1
            for i in range(3):
                try:
                    ManualMetrics[i][0].append(metrics.roc_auc_score(targetManualClass[i][len(targetManualClass[i])-1], outputProbaManualClass[i][len(outputProbaManualClass[i])-1]))
                except:
                    ManualMetrics[i][0].append(0.5)
                ManualMetrics[i][1].append(metrics.precision_score(targetManualClass[i][len(targetManualClass[i])-1], outputProbaManualClass[i][len(outputProbaManualClass[i])-1], pos_label = 1, average = 'binary'))
                ManualMetrics[i][2].append(metrics.precision_score(targetManualClass[i][len(targetManualClass[i])-1], outputProbaManualClass[i][len(outputProbaManualClass[i])-1], pos_label = 0, average = 'binary'))
                ManualMetrics[i][3].append(metrics.recall_score(targetManualClass[i][len(targetManualClass[i])-1], outputProbaManualClass[i][len(outputProbaManualClass[i])-1]))
            
                outputProbaManualClass0 = [1 if x==0 else 0 for x in outputProbaManualClass[i][len(outputProbaManualClass[i])-1]]
                targetManualClass0 = [1 if x==0 else 0 for x in targetManualClass[i][len(targetManualClass[i])-1]]

                ManualMetrics[i][4].append(metrics.recall_score(targetManualClass0, outputProbaManualClass0))

            for metricsInterval in ManualMetricsDict:
                try:
                    ManualMetricsDict[metricsInterval]['auc'].append(metrics.roc_auc_score(ManualClassDict[metricsInterval]['target'], ManualClassDict[metricsInterval]['prediction']))
                except:
                     ManualMetricsDict[metricsInterval]['auc'].append(0.5)
                ManualMetricsDict[metricsInterval]['precision0'].append(metrics.precision_score(ManualClassDict[metricsInterval]['target'], ManualClassDict[metricsInterval]['prediction'], pos_label = 0, average = 'binary'))
                ManualMetricsDict[metricsInterval]['precision1'].append(metrics.precision_score(ManualClassDict[metricsInterval]['target'], ManualClassDict[metricsInterval]['prediction'], pos_label = 1, average = 'binary'))
                ManualMetricsDict[metricsInterval]['recall1'].append(metrics.recall_score(ManualClassDict[metricsInterval]['target'], ManualClassDict[metricsInterval]['prediction']))

                outputProbaManualClass0 = [1 if x==0 else 0 for x in ManualClassDict[metricsInterval]['prediction']]
                targetManualClass0 = [1 if x==0 else 0 for x in ManualClassDict[metricsInterval]['target']]

                ManualMetricsDict[metricsInterval]['recall0'].append(metrics.recall_score(targetManualClass0, outputProbaManualClass0))

            if currAUC < metrics.roc_auc_score(testTarget, output):
                currModel = classifier
                currAUC = auc[len(auc)-1]
                currRecall1 = recall1[len(recall1)-1]
                currRecall0 = recall0[len(recall0)-1]
                currAcc = acc[len(acc)-1]
                currPre1 = precision1[len(precision1)-1]
                currPre0 = precision0[len(precision0)-1]
                currmanPre0 = []
                currmanPre1 = []
                #for j in range(3):  
                #    currmanPre0.append(ManualMetrics[j][2][len(ManualMetrics[j][2])-1])
                #    currmanPre1.append(ManualMetrics[j][1][len(ManualMetrics[j][1])-1])

                for metricsInterval in ManualMetricsDict:
                    currmanPre0.append(ManualMetricsDict[metricsInterval]['precision0'][len(ManualMetricsDict[metricsInterval]['precision0'])-1])
                    currmanPre1.append(ManualMetricsDict[metricsInterval]['precision1'][len(ManualMetricsDict[metricsInterval]['precision1'])-1])
                currPCA = pca
                currfeatureSel = featureSel
        
        #means of metrics
        precisiontop5 = sum(precisiontop5) / len(precisiontop5)
        precision1Mean = sum(precision1) / len(precision1)
        precision0Mean = sum(precision0) / len(precision0)
        aucMean = sum(auc) / len(auc)
        recall1Mean = sum(recall1) / len(recall1)
        recall0Mean = sum(recall0) / len(recall0)
        accMean = sum(acc) / len(acc)
        for j in range(3):
            for i in range(5):
                ManualMetrics[j][i] = sum(ManualMetrics[j][i])/len(ManualMetrics[j][i])

        for metricsInterval in ManualMetricsDict:
            for metric in ManualMetricsDict[metricsInterval]:
                ManualMetricsDict[metricsInterval][metric] = sum(ManualMetricsDict[metricsInterval][metric])/len(ManualMetricsDict[metricsInterval][metric])
        
        outputMetrics = {'auc':currAUC, 'accuracy':currAcc, 'precision':[currPre0, currPre1], 'recall':[currRecall0,currRecall1], 'manualPrecision': [currmanPre0, currmanPre1]}

        with open('dumped_pca'+str(kVal)+'.pkl', 'wb') as fid:
            pickle.dump(currPCA, fid) 

        with open('dumped_featureSelection'+str(kVal)+'.pkl', 'wb') as fid:
            pickle.dump(currfeatureSel, fid) 

        with open('dumped_classifier'+str(kVal)+'.pkl', 'wb') as fid:
            pickle.dump(currModel, fid) 

        with open('dumped_metrics'+str(kVal)+'.pkl', 'wb') as fid:
            pickle.dump(outputMetrics, fid)

        return [aucMean, accMean, [precision0Mean, precision1Mean], recall1Mean, recall0Mean, [outputClasses, testClasses], outputProbaManualClass, precisiontop5, ManualMetrics, unsortedOutputProba, [topClassCorrect, midClass, bottomClassCorrect], outputMetrics, classifier, featureSel, pca]

    #generate 10 regressors and return mean of metrics
    def single10FoldRegression(self, allSubjects, kVal, folds, pcaVal):

        c = Classifier()

        classArray = [float(row[49]) for row in allSubjects]
        allSubjects = c.RemoveIrrelevantColumns(allSubjects, False)
        classArray, allSubjects = c.shuffle(classArray, allSubjects, False)

        #initialisation
        allSubjects = np.array(allSubjects)
        classArray = np.array(classArray)
        auc = []
        evs = []
        meanae = []
        mse = []
        medae = []
        r2 = []
        outputClasses = []
        testClasses = []

        #go through all folds
        for trainI, testI in folds:
            testSet = [item.tolist() for item in allSubjects[testI]]
            testTarget = [item.tolist() for item in classArray[testI]]
            trainSet = [item.tolist() for item in allSubjects[trainI]]
            trainTarget = [item.tolist() for item in classArray[trainI]]

            testTarget, testSet = c.shuffle(testTarget, testSet)
            trainTarget, trainSet = c.shuffle(trainTarget, trainSet)

            #PCA
            pca = decomposition.PCA(pcaVal)
            pca.fit(trainSet)
            testSet = pca.transform(testSet)
            trainSet = pca.transform(trainSet)

            #select kVal features
            [trainSet, testSet] = c.FeatureSelection(trainSet, trainTarget, testSet, 1, kVal)

            regressor = ensemble.ExtraTreesRegressor(n_estimators=128, criterion='mse', max_depth=None, min_samples_split=2,
                                                     min_samples_leaf=50, min_weight_fraction_leaf=0, max_features="sqrt", max_leaf_nodes=None,
                                                     bootstrap=True, oob_score=True, n_jobs=-1, random_state=None, 
                                                     verbose=0, warm_start=False)
            boostedRegressor = ensemble.AdaBoostRegressor(base_estimator = regressor, n_estimators=500, learning_rate=0.5)
            boostedRegressor.fit(trainSet,trainTarget)

            output = boostedRegressor.predict(testSet).tolist()

            testTarget, output = zip(*sorted(zip(testTarget, output)))
            
            #metrics
            auc.append(metrics.auc(testTarget, output))
            evs.append(metrics.explained_variance_score(testTarget, output))
            meanae.append(metrics.mean_absolute_error(testTarget, output))
            mse.append(metrics.mean_squared_error(testTarget, output))
            medae.append(metrics.median_absolute_error(testTarget, output))
            r2.append(metrics.r2_score(testTarget, output))
        
            outputClasses.append(output)
            testClasses.append(testTarget)

        #means of metrics
        aucMean = sum(auc) / len(auc)
        evsMean = sum(evs) / len(evs)
        meanaeMean = sum(meanae) / len(meanae)
        mseMean = sum(mse) / len(mse)
        medaeMean = sum(medae) / len(medae)
        r2Mean = sum(r2) / len(r2)
        return [evsMean, meanaeMean, mseMean, medaeMean, r2Mean, [outputClasses, testClasses], aucMean]

class ExtraTreesFeatureImportanceTransformator(TransformerMixin):
    def __init__(self, X, Y, FeatureAmount, Trees):
        self.trainY = Y
        self.trainX = X
        self.amount = FeatureAmount
        self.trees = Trees
        self.forest = ensemble.ExtraTreesClassifier(n_estimators = self.trees)
        self.forest.fit(self.trainX, self.trainY)

    def transform(self, X, *_):
        featureList = []

        importances = self.forest.feature_importances_
        indices = np.argsort(importances)[-self.amount:]

        for i in X:
            newI = np.array(i)[indices].tolist()
            featureList.append(newI)

        return featureList
    
    def fit(self, *_):
        return self

class SVMTransformator(TransformerMixin):
    def __init__(self, X, Y, FeatureAmount):
        self.trainY = Y
        self.trainX = X
        self.amount = FeatureAmount
        self.svm = svm.SVC(kernel='linear')
        self.svm.fit(self.trainX, self.trainY)

    def transform(self, X, *_):
        featureList = []

        [importances] = self.svm._get_coef().tolist()
        importances = [abs(item) for item in importances]
        indices = np.argsort(importances)[-self.amount:]

        for i in X:
            newI = np.array(i)[indices].tolist()
            featureList.append(newI)

        return featureList
    
    def fit(self, *_):
        return self

class NNTransformator(TransformerMixin):
    def __init__(self, X, Components):
        self.trainX = X
        self.components = Components
        self.nn = neural_network.BernoulliRBM(n_components = self.components)
        self.nn.fit(self.trainX)

    def transform(self, X, *_):
        featureList = []

        features = self.nn.transform(X).tolist()
        return features
    
    def fit(self, *_):
        return self