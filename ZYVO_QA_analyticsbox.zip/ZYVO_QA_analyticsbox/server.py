from tornado.wsgi import WSGIContainer
from tornado.httpserver import HTTPServer
from tornado.ioloop import IOLoop
from flask_api import app

if __name__ == '__main__':
    http_server = HTTPServer(WSGIContainer(app)) #, ssl_options={
       #"certfile":'server.crt',
       # "keyfile":'server.key'
    #})
    http_server.listen(8000)
    test = http_server._sockets
    IOLoop.instance().start()
